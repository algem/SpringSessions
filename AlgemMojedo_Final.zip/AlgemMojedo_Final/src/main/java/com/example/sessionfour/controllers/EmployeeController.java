package com.example.sessionfour.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.sessionfour.exceptions.RecordNotFoundException;
import com.example.sessionfour.models.Employee;
import com.example.sessionfour.models.Skill;
import com.example.sessionfour.models.CreateSkillRequest;
import com.example.sessionfour.services.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService service;
	
	@GetMapping(params = { "page", "size", "sort", "sortDirection" })
	public ResponseEntity<Page<Employee>> get(@RequestParam("page") int page, @RequestParam("size") int size, 
	@RequestParam("sort") String sort, @RequestParam("sortDirection") String sortDirection) {
		PageRequest pageRequest = PageRequest.of(page, size, Sort.by(Direction.fromString(sortDirection), sort));
		return new ResponseEntity<Page<Employee>>(service.get(pageRequest), new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Employee> get(@PathVariable("id") Long id) throws RecordNotFoundException {
		return new ResponseEntity<Employee>(service.get(id), new HttpHeaders(), HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<Employee> save(@RequestBody Employee employee) {
		return new ResponseEntity<Employee>(service.create(employee), new HttpHeaders(), HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Employee> save(@PathVariable("id") Long id, @RequestBody Employee employee) throws RecordNotFoundException {
		return new ResponseEntity<Employee>(service.update(id, employee), new HttpHeaders(), HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(@PathVariable("id") Long id) throws RecordNotFoundException {
		service.delete(id);
		return ResponseEntity.ok().build();
	}
	
	@GetMapping(path = "/{id}/skills", params = { "page", "size", "sort", "sortDirection" })
	public ResponseEntity<Page<Skill>> getSkill(@PathVariable("id") Long id, @RequestParam("page") int page, 
	@RequestParam("size") int size, @RequestParam("sort") String sort, @RequestParam("sortDirection") String sortDirection) throws RecordNotFoundException {
		PageRequest pageRequest = PageRequest.of(page, size, Sort.by(Direction.fromString(sortDirection), sort));
		return new ResponseEntity<Page<Skill>>(service.getSkills(id, pageRequest), new HttpHeaders(), HttpStatus.OK);
	}
	
	@PostMapping("/{id}/skill")
	public ResponseEntity<Skill> saveSkill(@PathVariable("id") Long id, @RequestBody CreateSkillRequest skill) throws RecordNotFoundException {
		return new ResponseEntity<Skill>(service.createSkill(id, skill), new HttpHeaders(), HttpStatus.CREATED);
	}
}