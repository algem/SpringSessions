package com.example.sessionfour;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Run this in browser...
// http://localhost:8080/swagger-ui/index.html

@SpringBootApplication
public class SessionFourApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionFourApplication.class, args);
	}

}
